import firebase from 'firebase';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBRixhEHToE7fBXdulVLI1kWOvx9PSNs1s",
  authDomain: "project-58-833d5.firebaseapp.com",
  databaseURL: "https://project-58-833d5-default-rtdb.firebaseio.com",
  projectId: "project-58-833d5",
  storageBucket: "project-58-833d5.appspot.com",
  messagingSenderId: "537713750633",
  appId: "1:537713750633:web:d0d08f06d18f89e428a8f8",
  measurementId: "G-CNK9VH590K"
};

firebase.initializeApp(firebaseConfig);

export default firebase.database();